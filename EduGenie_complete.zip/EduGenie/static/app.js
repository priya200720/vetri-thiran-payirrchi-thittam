const task = document.getElementById("task");
const inputText = document.getElementById("inputText");
const submitBtn = document.getElementById("submitBtn");
const clearBtn = document.getElementById("clearBtn");
const result = document.getElementById("result");
const copyBtn = document.getElementById("copyBtn");
const statusPill = document.getElementById("statusPill");

const endpoints = {
  qa: "/qa",
  explain: "/explain",
  quiz: "/quiz",
  summarize: "/summarize",
  learn: "/learn/recommendations",
};

function setBusy(busy) {
  submitBtn.disabled = busy;
  statusPill.textContent = busy ? "Thinking…" : "Ready";
}

function showText(text) {
  result.className = "result";
  result.textContent = text;
  copyBtn.hidden = false;
}

function showQuiz(data) {
  result.className = "result";
  result.innerHTML = "";

  data.questions.forEach((q, index) => {
    const box = document.createElement("div");
    box.className = "quiz-question";

    const title = document.createElement("strong");
    title.textContent = `${index + 1}. ${q.question}`;
    box.appendChild(title);

    const feedback = document.createElement("div");
    feedback.className = "quiz-feedback";

    q.options.forEach(option => {
      const button = document.createElement("button");
      button.className = "quiz-option";
      button.textContent = option;

      button.addEventListener("click", () => {
        box.querySelectorAll(".quiz-option").forEach(b => b.disabled = true);
        if (option === q.answer) {
          button.classList.add("correct");
          feedback.textContent = "✓ Correct! " + (q.explanation || "");
        } else {
          button.classList.add("wrong");
          feedback.textContent = `✗ Not quite. Correct answer: ${q.answer}. ${q.explanation || ""}`;
          box.querySelectorAll(".quiz-option").forEach(b => {
            if (b.textContent === q.answer) b.classList.add("correct");
          });
        }
      });

      box.appendChild(button);
    });

    box.appendChild(feedback);
    result.appendChild(box);
  });

  copyBtn.hidden = true;
}

async function submit() {
  const text = inputText.value.trim();
  if (!text) {
    showText("Please enter a question, topic, or passage.");
    return;
  }

  setBusy(true);
  result.className = "result";
  result.textContent = "Generating your learning response…";
  copyBtn.hidden = true;

  try {
    const response = await fetch(endpoints[task.value], {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "The server returned an error.");
    }

    if (task.value === "quiz") {
      showQuiz(data);
    } else {
      const key = {
        qa: "answer",
        explain: "explanation",
        summarize: "summary",
        learn: "learning_path",
      }[task.value];
      showText(data[key]);
    }
  } catch (error) {
    showText(`Error: ${error.message}`);
  } finally {
    setBusy(false);
  }
}

submitBtn.addEventListener("click", submit);

clearBtn.addEventListener("click", () => {
  inputText.value = "";
  result.className = "result empty";
  result.textContent = "Your generated answer will appear here.";
  copyBtn.hidden = true;
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(result.innerText);
  copyBtn.textContent = "Copied";
  setTimeout(() => copyBtn.textContent = "Copy", 1200);
});
