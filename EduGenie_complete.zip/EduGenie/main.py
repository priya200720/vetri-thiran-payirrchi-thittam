from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from qna import answer_question
from explanation_module import explain_concept
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations
from schemas import (
    TextRequest, QAResponse, ExplainResponse, QuizResponse,
    SummaryResponse, LearningPathResponse
)

app = FastAPI(
    title="EduGenie",
    description="Google Gemini powered learning assistant",
    version="1.0.0",
)

BASE_DIR = Path(__file__).resolve().parent
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/health")
async def health():
    return {"status": "ok", "service": "EduGenie"}


@app.post("/qa", response_model=QAResponse)
async def qa(payload: TextRequest):
    return QAResponse(answer=await answer_question(payload.text))


@app.post("/explain", response_model=ExplainResponse)
async def explain(payload: TextRequest):
    return ExplainResponse(explanation=await explain_concept(payload.text))


@app.post("/quiz", response_model=QuizResponse)
async def quiz(payload: TextRequest):
    return await generate_quiz(payload.text)


@app.post("/summarize", response_model=SummaryResponse)
async def summarize(payload: TextRequest):
    return SummaryResponse(summary=await summarize_text(payload.text))


@app.post("/learn/recommendations", response_model=LearningPathResponse)
async def learn(payload: TextRequest):
    return LearningPathResponse(
        learning_path=await get_learning_recommendations(payload.text)
    )
