from schemas import QuizResponse, QuizQuestion
from ai_service import AIServiceError


def normalize_quiz(data) -> QuizResponse:
    if not isinstance(data, dict) or not isinstance(data.get("questions"), list):
        raise AIServiceError("Quiz response does not contain a questions list.")

    questions = []
    for item in data["questions"][:3]:
        if not isinstance(item, dict):
            continue
        options = item.get("options", [])
        answer = str(item.get("answer", "")).strip()
        if len(options) != 4 or answer not in [str(x) for x in options]:
            raise AIServiceError("Quiz contains an invalid question or answer.")
        questions.append(
            QuizQuestion(
                question=str(item.get("question", "")).strip(),
                options=[str(x).strip() for x in options],
                answer=answer,
                explanation=str(item.get("explanation", "")).strip(),
            )
        )

    if len(questions) != 3:
        raise AIServiceError("Gemini did not generate exactly 3 valid questions.")

    return QuizResponse(questions=questions)
