from ai_service import generate_text
from config import get_settings

_local_pipeline = None


def _local_explain_sync(topic: str) -> str:
    global _local_pipeline
    if _local_pipeline is None:
        from transformers import pipeline
        _local_pipeline = pipeline(
            "text2text-generation",
            model=get_settings().local_explain_model,
            device=-1,
        )

    prompt = (
        "Explain this educational topic in very simple language for a beginner. "
        "Use short paragraphs and one everyday example if appropriate. "
        f"Topic: {topic}"
    )
    result = _local_pipeline(prompt, max_new_tokens=220, do_sample=False)
    return result[0]["generated_text"].strip()


async def explain_concept(topic: str) -> str:
    settings = get_settings()

    if settings.enable_local_explain:
        try:
            import asyncio
            return await asyncio.to_thread(_local_explain_sync, topic)
        except Exception:
            # Keep the application usable if the optional local model is unavailable.
            pass

    prompt = f"""
Explain the following concept to a student who is new to it.

Requirements:
1. Start with a one-sentence definition.
2. Explain the idea using simple words.
3. Give a small example or analogy.
4. End with 2-3 key points to remember.
5. Avoid unnecessary jargon.

Topic:
{topic}
"""
    return await generate_text(
        prompt,
        system_instruction="You are a patient educational explainer.",
        max_output_tokens=1100,
    )
