from ai_service import generate_text


async def answer_question(question: str) -> str:
    prompt = f"""
You are EduGenie, an educational question-answering assistant.

Answer the student's question accurately and concisely.
- Use simple language.
- Give the direct answer first.
- Add a short explanation when useful.
- If the question is ambiguous, state the assumption you made.
- Do not invent sources or citations.

Student question:
{question}
"""
    return await generate_text(
        prompt,
        system_instruction="You are a careful, student-friendly academic tutor.",
        max_output_tokens=1000,
    )
