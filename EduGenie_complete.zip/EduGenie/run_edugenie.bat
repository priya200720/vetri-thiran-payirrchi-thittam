@echo off
setlocal
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found.
  echo Create it with: py -3.12 -m venv .venv
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python -m uvicorn main:app --reload
