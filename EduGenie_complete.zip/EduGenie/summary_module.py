from ai_service import generate_text


async def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational passage for quick revision.

Requirements:
- Preserve the important facts and meaning.
- Remove repetition and minor details.
- Use simple, clear language.
- Prefer a short heading followed by concise bullet points.
- Do not introduce information that is absent from the passage.

Passage:
{text}
"""
    return await generate_text(
        prompt,
        system_instruction="You are an educational summarization assistant.",
        max_output_tokens=1200,
    )
