import os
from functools import lru_cache

from dotenv import load_dotenv

load_dotenv()


class Settings:
    app_name: str = os.getenv("APP_NAME", "EduGenie")
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    # Change this without modifying source code when Google changes model availability.
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
    local_explain_model: str = os.getenv(
        "LOCAL_EXPLAIN_MODEL",
        "MBZUAI/LaMini-Flan-T5-783M",
    )
    enable_local_explain: bool = os.getenv(
        "ENABLE_LOCAL_EXPLAIN", "false"
    ).lower() == "true"
    max_input_chars: int = int(os.getenv("MAX_INPUT_CHARS", "20000"))
    max_quiz_questions: int = int(os.getenv("MAX_QUIZ_QUESTIONS", "3"))


@lru_cache
def get_settings() -> Settings:
    return Settings()
