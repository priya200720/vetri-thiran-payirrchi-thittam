from pydantic import BaseModel, Field, field_validator


class TextRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=20000)

    @field_validator("text")
    @classmethod
    def clean_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Input cannot be empty.")
        return value


class QAResponse(BaseModel):
    answer: str


class ExplainResponse(BaseModel):
    explanation: str


class QuizQuestion(BaseModel):
    question: str
    options: list[str] = Field(..., min_length=4, max_length=4)
    answer: str
    explanation: str = ""


class QuizResponse(BaseModel):
    questions: list[QuizQuestion] = Field(..., min_length=1, max_length=10)


class SummaryResponse(BaseModel):
    summary: str


class LearningPathResponse(BaseModel):
    learning_path: str
