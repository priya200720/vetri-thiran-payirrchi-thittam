# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a FastAPI + HTML/CSS/JavaScript educational assistant based on the supplied project documentation.

## Features

- Q&A: `/qa`
- Concept explanation: `/explain`
- MCQ quiz generation: `/quiz`
- Passage summarization: `/summarize`
- Personalized learning path: `/learn/recommendations`
- Responsive web UI
- JSON REST APIs
- Health endpoint
- Automated API smoke tests
- Optional LaMini-Flan-T5-783M local explanation model

## Architecture

```text
EduGenie/
├── main.py
├── config.py
├── schemas.py
├── ai_service.py
├── qna.py
├── explanation_module.py
├── quiz_module.py
├── quiz_service_helpers.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── tests/
    └── test_api.py
```

## Model note

The original document specifies Gemini 1.5 Pro for Q&A, summarization, quizzes, and learning paths, and LaMini-Flan-T5-783M for explanations. The implementation keeps both roles configurable.

`GEMINI_MODEL` defaults to a current Gemini text model. If your Google AI Studio account does not provide that model, set `GEMINI_MODEL` to a model available to your API key.

The local LaMini model is optional because it is substantially heavier than the rest of the application. Set:

```env
ENABLE_LOCAL_EXPLAIN=true
```

to use it for `/explain`. If it cannot be loaded, EduGenie automatically falls back to Gemini.

## Windows / VS Code setup

### 1. Open the project

Open this folder in VS Code:

```text
EduGenie
```

### 2. Create a virtual environment

PowerShell:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```bat
py -3.12 -m venv .venv
.venv\Scripts\activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

For a lighter installation that does not download PyTorch/Transformers, remove the optional three ML lines from `requirements.txt` before installing. The default Gemini explanation path does not need them.

### 4. Configure Gemini

Copy:

```text
.env.example
```

to:

```text
.env
```

Then add your Google AI Studio API key:

```env
GEMINI_API_KEY=YOUR_REAL_KEY
```

Never commit `.env` to Git.

### 5. Run the application

```bash
python -m uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

API documentation:

```text
http://127.0.0.1:8000/docs
```

## Testing

Run automated tests:

```bash
pytest -q
```

The tests that exercise Gemini itself require a valid API key. For a manual end-to-end test, open the web page and try:

1. Q&A — `Which is the largest ocean?`
2. Explain — `Explain the Pythagoras theorem for a beginner.`
3. Quiz — paste a short educational paragraph.
4. Summary — paste a long paragraph.
5. Learning path — `SQL for a beginner who wants to become job-ready.`

## REST API examples

### Q&A

```bash
curl -X POST http://127.0.0.1:8000/qa ^
  -H "Content-Type: application/json" ^
  -d "{\"text\":\"Which is the largest ocean?\"}"
```

### Explanation

```bash
curl -X POST http://127.0.0.1:8000/explain ^
  -H "Content-Type: application/json" ^
  -d "{\"text\":\"Explain photosynthesis simply.\"}"
```

### Quiz

```bash
curl -X POST http://127.0.0.1:8000/quiz ^
  -H "Content-Type: application/json" ^
  -d "{\"text\":\"Python is a high-level programming language used for web development, data analysis, automation, and AI.\"}"
```

## Run as Administrator

Administrator privileges are normally **not required** for EduGenie. Run VS Code/PowerShell normally.

If Windows gives a permissions error while installing Python packages, close VS Code, open **Windows Terminal or PowerShell → Run as administrator**, then repeat the virtual-environment and installation commands.

Do not store the Gemini API key in source code or in screenshots.

## Troubleshooting

### `GEMINI_API_KEY is not configured`

Make sure `.env` exists beside `main.py` and contains:

```env
GEMINI_API_KEY=...
```

Restart Uvicorn after changing `.env`.

### Model not found / unavailable

Change:

```env
GEMINI_MODEL=...
```

to a text-generation model currently enabled for your Google AI Studio account.

### `transformers` or `torch` installation is difficult

Leave:

```env
ENABLE_LOCAL_EXPLAIN=false
```

and use the lightweight Gemini explanation path. The local LaMini feature is optional.

### Port 8000 is already in use

```bash
python -m uvicorn main:app --reload --port 8001
```

Then open `http://127.0.0.1:8001`.

## Security checklist

- Keep `.env` private.
- Never expose the Gemini key in frontend JavaScript.
- Keep API input limits enabled.
- For production, add authentication, rate limiting, HTTPS, logging, and secret management.
- Do not treat AI-generated educational content as authoritative without verification.

## Project mapping to the supplied documentation

| Documentation requirement | Implementation |
|---|---|
| FastAPI backend | `main.py` |
| Explanation module | `explanation_module.py` |
| Q&A | `qna.py` |
| Quiz | `quiz_module.py` |
| Summary | `summary_module.py` |
| Learning path | `learning_path.py` |
| HTML frontend | `templates/index.html` |
| CSS | `static/style.css` |
| REST endpoints | FastAPI routes in `main.py` |
| Gemini integration | `ai_service.py` |
| JSON quiz handling | `quiz_service_helpers.py` |
| Local LaMini option | `explanation_module.py` |
| Uvicorn deployment | `python -m uvicorn main:app --reload` |
