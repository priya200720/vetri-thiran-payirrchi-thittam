from quiz_service_helpers import normalize_quiz
from ai_service import generate_text, parse_json


async def generate_quiz(passage: str):
    prompt = f"""
Create exactly 3 multiple-choice questions from the educational text below.

Return ONLY valid JSON in this exact shape:
{{
  "questions": [
    {{
      "question": "Question text",
      "options": ["A", "B", "C", "D"],
      "answer": "The exact correct option text",
      "explanation": "Brief explanation"
    }}
  ]
}}

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- Only one correct answer.
- Distractors must be plausible.
- Questions must be answerable from the supplied text.
- Do not use Markdown.

Educational text:
{passage}
"""
    raw = await generate_text(
        prompt,
        system_instruction="You generate structured educational assessments.",
        json_mode=True,
        max_output_tokens=1800,
    )
    return normalize_quiz(parse_json(raw))
