import asyncio
import json
from typing import Any

from config import get_settings

try:
    from google import genai
    from google.genai import types
except ImportError:  # pragma: no cover
    genai = None
    types = None


class AIServiceError(RuntimeError):
    """Raised when the configured AI provider cannot complete a request."""


def _client():
    settings = get_settings()
    if genai is None:
        raise AIServiceError(
            "google-genai is not installed. Run: pip install -r requirements.txt"
        )
    if not settings.gemini_api_key:
        raise AIServiceError(
            "GEMINI_API_KEY is not configured. Copy .env.example to .env and add your key."
        )
    return genai.Client(api_key=settings.gemini_api_key)


def _generate_sync(
    prompt: str,
    *,
    system_instruction: str | None = None,
    json_mode: bool = False,
    max_output_tokens: int = 1200,
) -> str:
    settings = get_settings()
    client = _client()

    config_kwargs: dict[str, Any] = {
        "temperature": 0.4,
        "max_output_tokens": max_output_tokens,
    }
    if system_instruction:
        config_kwargs["system_instruction"] = system_instruction
    if json_mode:
        config_kwargs["response_mime_type"] = "application/json"

    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
        config=types.GenerateContentConfig(**config_kwargs),
    )

    text = getattr(response, "text", None)
    if not text:
        raise AIServiceError("Gemini returned an empty response.")
    return text.strip()


async def generate_text(
    prompt: str,
    *,
    system_instruction: str | None = None,
    json_mode: bool = False,
    max_output_tokens: int = 1200,
) -> str:
    return await asyncio.to_thread(
        _generate_sync,
        prompt,
        system_instruction=system_instruction,
        json_mode=json_mode,
        max_output_tokens=max_output_tokens,
    )


def clean_json_block(text: str) -> str:
    """Remove Markdown fences if a model returns ```json ... ```."""
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    return text


def parse_json(text: str) -> Any:
    try:
        return json.loads(clean_json_block(text))
    except json.JSONDecodeError as exc:
        raise AIServiceError(f"Model returned invalid JSON: {exc}") from exc
