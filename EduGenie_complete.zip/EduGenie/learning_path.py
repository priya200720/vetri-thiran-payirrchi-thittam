from ai_service import generate_text


async def get_learning_recommendations(topic: str) -> str:
    prompt = f"""
Create a personalized learning path for the topic below.

Structure it as:
1. Goal
2. Beginner foundations
3. Intermediate topics
4. Advanced topics
5. Suggested timeline
6. Practice/project ideas
7. Learning resources (describe resource types such as official docs,
   textbooks, or reputable tutorials; do not invent exact links)
8. A simple self-assessment checklist

Make the progression realistic and easy for a learner to follow.
Topic:
{topic}
"""
    return await generate_text(
        prompt,
        system_instruction="You are an academic learning-path designer.",
        max_output_tokens=1800,
    )
